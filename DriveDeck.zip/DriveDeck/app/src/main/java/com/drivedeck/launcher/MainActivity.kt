package com.drivedeck.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), LocationListener {

    // ---------- Settings you may want to tweak ----------
    /** Block video apps while GPS says the vehicle is moving faster than this (m/s). 2.2 m/s is about 5 mph. */
    private val videoLockSpeedMps = 2.2f
    /** Set to false to disable the parked-only lock for video apps. */
    private val videoLockEnabled = true

    // ---------- Theme ----------
    private val bg = Color.parseColor("#0B0F14")
    private val rail = Color.parseColor("#10161D")
    private val card = Color.parseColor("#18202A")
    private val accent = Color.parseColor("#8AB4F8")
    private val textPrimary = Color.WHITE
    private val textSecondary = Color.parseColor("#9AA4B2")

    private data class Fav(
        val label: String,
        val packages: List<String>,
        val color: Int,
        val isVideo: Boolean = false
    )

    private val favorites by lazy {
        listOf(
            Fav("Waze", listOf("com.waze"), Color.parseColor("#33CCFF")),
            Fav("Maps", listOf("com.google.android.apps.maps"), Color.parseColor("#34A853")),
            Fav("Spotify", listOf("com.spotify.music"), Color.parseColor("#1DB954")),
            Fav("YT Music", listOf("com.google.android.apps.youtube.music"), Color.parseColor("#FF4E45")),
            Fav("YouTube", listOf("com.google.android.youtube"), Color.parseColor("#FF0000"), true),
            Fav("Netflix", listOf("com.netflix.mediaclient"), Color.parseColor("#E50914"), true)
        )
    }

    private val videoPackages = setOf(
        "com.netflix.mediaclient",
        "com.google.android.youtube",
        "com.disney.disneyplus",
        "com.amazon.avod.thirdpartyclient",
        "com.google.android.youtube.tv"
    )

    private lateinit var content: FrameLayout
    private lateinit var statusText: TextView
    private var showingAllApps = false
    private var currentSpeedMps: Float? = null

    // ---------- Lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(bg)
        setContentView(buildRoot())
        showHome()
        requestLocationIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        startSpeedUpdates()
        showHome()
    }

    override fun onPause() {
        super.onPause()
        stopSpeedUpdates()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingAllApps) showHome()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    // ---------- UI ----------
    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
        }

        // Left rail, similar to Android Auto's nav bar
        val railView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(rail)
            setPadding(dp(8), dp(16), dp(8), dp(16))
        }

        val clock = TextClock(this).apply {
            format12Hour = "HH:mm"
            format24Hour = "HH:mm"
            textSize = 22f
            setTextColor(textPrimary)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        railView.addView(clock)

        statusText = TextView(this).apply {
            textSize = 11f
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
            text = ""
        }
        railView.addView(statusText)

        railView.addView(spacer(dp(20)))
        railView.addView(railButton("Home", android.R.drawable.ic_menu_compass) { showHome() })
        railView.addView(railButton("Phone", android.R.drawable.sym_action_call) { openPhone() })
        railView.addView(railButton("Messages", android.R.drawable.sym_action_chat) { openMessages() })
        railView.addView(railButton("Apps", android.R.drawable.ic_menu_agenda) { showAllApps() })

        root.addView(railView, LinearLayout.LayoutParams(dp(104), ViewGroup.LayoutParams.MATCH_PARENT))

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        return root
    }

    private fun railButton(label: String, icon: Int, onClick: () -> Unit): View {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(10), dp(4), dp(10))
            background = rounded(Color.TRANSPARENT, dp(16))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val img = ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(accent)
        }
        v.addView(img, LinearLayout.LayoutParams(dp(30), dp(30)))
        v.addView(TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(textSecondary)
            gravity = Gravity.CENTER
        })
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        v.layoutParams = lp
        return v
    }

    private fun showHome() {
        showingAllApps = false
        content.removeAllViews()

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }

        column.addView(TextView(this).apply {
            text = "Drive"
            textSize = 28f
            setTextColor(textPrimary)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        column.addView(TextView(this).apply {
            text = "Your apps"
            textSize = 14f
            setTextColor(textSecondary)
            setPadding(0, 0, 0, dp(16))
        })

        val grid = GridLayout(this).apply { columnCount = 3 }
        for (fav in favorites) {
            val installedPkg = fav.packages.firstOrNull { isInstalled(it) }
            grid.addView(tile(fav.label, installedPkg?.let { iconFor(it) }, fav.color, installedPkg != null) {
                if (installedPkg == null) {
                    toast("${fav.label} isn't installed on this adapter yet")
                } else {
                    launchPackage(installedPkg, fav.isVideo)
                }
            })
        }
        grid.addView(tile("Phone", getDrawable(android.R.drawable.sym_action_call), Color.parseColor("#34A853"), true) { openPhone() })
        grid.addView(tile("Messages", getDrawable(android.R.drawable.sym_action_chat), Color.parseColor("#4285F4"), true) { openMessages() })
        grid.addView(tile("All apps", getDrawable(android.R.drawable.ic_menu_agenda), accent, true) { showAllApps() })

        column.addView(grid)
        scroll.addView(column)
        content.addView(scroll)
    }

    private fun showAllApps() {
        showingAllApps = true
        content.removeAllViews()

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }
        column.addView(TextView(this).apply {
            text = "All apps"
            textSize = 28f
            setTextColor(textPrimary)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(16))
        })

        val grid = GridLayout(this).apply { columnCount = 4 }
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launchIntent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        for (info in apps) {
            val pkg = info.activityInfo.packageName
            val label = info.loadLabel(packageManager).toString()
            grid.addView(tile(label, info.loadIcon(packageManager), card, true, small = true) {
                launchPackage(pkg, pkg in videoPackages)
            })
        }
        column.addView(grid)
        scroll.addView(column)
        content.addView(scroll)
    }

    private fun tile(
        label: String,
        icon: Drawable?,
        color: Int,
        enabled: Boolean,
        small: Boolean = false,
        onClick: () -> Unit
    ): View {
        val size = if (small) dp(130) else dp(170)
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12))
            background = rounded(if (small) card else blend(card, color), dp(24))
            alpha = if (enabled) 1f else 0.45f
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val iconSize = if (small) dp(56) else dp(72)
        val img = ImageView(this).apply {
            if (icon != null) setImageDrawable(icon)
            if (icon != null && !small && color == accent) setColorFilter(accent)
        }
        v.addView(img, LinearLayout.LayoutParams(iconSize, iconSize))
        v.addView(TextView(this).apply {
            text = label
            textSize = if (small) 12f else 15f
            setTextColor(textPrimary)
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(0, dp(8), 0, 0)
        })
        val lp = GridLayout.LayoutParams().apply {
            width = size
            height = if (small) dp(120) else dp(140)
            setMargins(dp(8), dp(8), dp(8), dp(8))
        }
        v.layoutParams = lp
        return v
    }

    // ---------- Actions ----------
    private fun launchPackage(pkg: String, isVideo: Boolean) {
        if (isVideo && videoLockEnabled && isMoving()) {
            AlertDialog.Builder(this)
                .setTitle("Parked only")
                .setMessage("Video is disabled while the vehicle is moving. Pull over safely to use it.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Can't open that app")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun openPhone() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            toast("No phone app found on this adapter")
        }
    }

    private fun openMessages() {
        try {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("No messaging app found on this adapter")
        }
    }

    // ---------- Speed / parked lock ----------
    private fun isMoving(): Boolean {
        val s = currentSpeedMps ?: return false // no speed data: don't block
        return s > videoLockSpeedMps
    }

    private fun requestLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startSpeedUpdates()
    }

    private fun startSpeedUpdates() {
        try {
            if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) return
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            }
        } catch (e: SecurityException) {
            // permission missing: leave speed unknown
        } catch (e: Exception) {
            // provider unavailable: leave speed unknown
        }
    }

    private fun stopSpeedUpdates() {
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
        } catch (e: Exception) {
        }
    }

    override fun onLocationChanged(location: Location) {
        currentSpeedMps = if (location.hasSpeed()) location.speed else null
        val s = currentSpeedMps
        statusText.text = when {
            s == null -> ""
            s > videoLockSpeedMps -> "DRIVING"
            else -> "PARKED"
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
    }

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {
        currentSpeedMps = null
        statusText.text = ""
    }

    // ---------- Helpers ----------
    private fun isInstalled(pkg: String): Boolean =
        packageManager.getLaunchIntentForPackage(pkg) != null

    private fun iconFor(pkg: String): Drawable? = try {
        packageManager.getApplicationIcon(pkg)
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    /** Slightly tint the card colour toward the app's brand colour. */
    private fun blend(base: Int, tint: Int): Int {
        val r = (Color.red(base) * 0.85f + Color.red(tint) * 0.15f).toInt()
        val g = (Color.green(base) * 0.85f + Color.green(tint) * 0.15f).toInt()
        val b = (Color.blue(base) * 0.85f + Color.blue(tint) * 0.15f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun spacer(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, h)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
