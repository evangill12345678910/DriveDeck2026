# DriveDeck

An Android Auto-style launcher for Android-based CarPlay / Android Auto adapters. Dark UI, left nav rail, big tiles for Waze, Maps, Spotify, YT Music, YouTube, Netflix, plus Phone, Messages and an All apps screen.

## Build the APK without Android Studio (GitHub, free, from a phone or PC)

1. Make a free account at github.com and create a new repository (private is fine).
2. Upload the contents of this folder to it. On the website: Add file > Upload files, and drag in everything, including the hidden `.github` folder. (If your browser won't upload the hidden folder, use Add file > Create new file, name it `.github/workflows/build.yml` and paste in that file's contents.)
3. Open the repository's Actions tab. The "Build APK" job starts by itself (or press Run workflow). It takes a few minutes.
4. Open the finished run and download `DriveDeck-apk` from Artifacts. Unzip it to get `app-debug.apk`.

## Install

Copy `app-debug.apk` to a USB stick and install it with the adapter's APK installer. Open "DriveDeck" from the adapter's app list.

If the build fails, open the failed run, copy the red error text and send it back; it is usually a one-line fix.

## Notes

- Tiles for apps that aren't installed are dimmed. Install Waze, Netflix, etc. on the adapter separately; this app only launches them.
- Video apps (YouTube, Netflix, Disney+, Prime Video) are blocked while GPS reports speed above about 5 mph. If the adapter has no GPS fix, nothing is blocked. Change `videoLockEnabled` / `videoLockSpeedMps` at the top of `MainActivity.kt`.
- Phone and Messages open the adapter's own dialer and messaging apps, not your phone's calls or texts.
- Add or change tiles in the `favorites` list in `MainActivity.kt`.
